#!/bin/sh

for F in *.bmp
do
 f="${F%.*}"
 convert $F -fuzz 4% -transparent white $f.gif
done
